filter_names = ('JPXDecode',)


def decode(binary, params):
    raise NotImplementedError('JPXDecode')