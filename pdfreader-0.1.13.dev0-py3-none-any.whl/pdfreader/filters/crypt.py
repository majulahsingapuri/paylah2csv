filter_names = ('Crypt',)


def decode(binary, params):
    raise NotImplementedError('Crypt')